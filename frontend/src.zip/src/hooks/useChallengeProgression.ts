// ===== Sprint 10.0 Challenge Progression Service =====
import { useCallback } from 'react';
import { SQLChallenge } from '../data/challenges';
import { useRequirementGate } from './useRequirementGate';

/**
 * Centralizes challenge progression decisions.
 * Consumes raw progression arrays and requirement engine data to provide
 * a clean, presentation-ready API for UI components.
 */
export const useChallengeProgression = (
  completedIds: string[],
  unlockedIds: string[],
  currentId: string
) => {
  const { isChallengeAccessible } = useRequirementGate(completedIds);

  const isCompleted = useCallback((challenge: SQLChallenge): boolean => {
    return completedIds.includes(challenge.id);
  }, [completedIds]);

  const isCurrent = useCallback((challenge: SQLChallenge): boolean => {
    return currentId === challenge.id;
  }, [currentId]);

  const isUnlocked = useCallback((challenge: SQLChallenge): boolean => {
    const isSequentiallyUnlocked = unlockedIds.includes(challenge.id);
    const isRequirementSatisfied = isChallengeAccessible(challenge);
    
    // The single source of truth for challenge accessibility
    return isSequentiallyUnlocked && isRequirementSatisfied;
  }, [unlockedIds, isChallengeAccessible]);

  return {
    isUnlocked,
    isCompleted,
    isCurrent
  };
};