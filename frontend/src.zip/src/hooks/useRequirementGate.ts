// ===== Sprint 9.8 Requirement Gate Engine START =====
import { useCallback } from 'react';
import { useInventory } from '../inventory/hooks/useInventory';
import { WorldManager } from '../systems/WorldManager';
import { WorldRequirement } from '../types/WorldTypes';
import { SQLChallenge } from '../data/challenges';

/**
 * Reusable engine that evaluates data-driven accessibility gates 
 * for Islands, NPCs, Locations, and Challenges based on current inventory and progress.
 */
export const useRequirementGate = (completedChallengeIds: string[] = []) => {
  const { hasItem } = useInventory();

  const isIslandAccessible = useCallback((requirements?: WorldRequirement) => {
    return WorldManager.isIslandAccessible(requirements, completedChallengeIds, hasItem);
  }, [completedChallengeIds, hasItem]);

  const isNPCAccessible = useCallback((requirements?: WorldRequirement) => {
    return WorldManager.isNPCAccessible(requirements, completedChallengeIds, hasItem);
  }, [completedChallengeIds, hasItem]);

  const isLocationUnlocked = useCallback((requirements?: WorldRequirement) => {
    return WorldManager.isLocationUnlocked(requirements, completedChallengeIds, hasItem);
  }, [completedChallengeIds, hasItem]);

  const isChallengeAccessible = useCallback((challenge: SQLChallenge) => {
    return WorldManager.isChallengeAccessible(
      challenge.requirements,
      challenge.requiredItem,
      completedChallengeIds,
      hasItem
    );
  }, [completedChallengeIds, hasItem]);

  console.log(
  isChallengeAccessible({
    id: "test",
    requirements: {
      requiredItem: "fake_item"
    }
  } as SQLChallenge)
);

  return {
    isIslandAccessible,
    isNPCAccessible,
    isLocationUnlocked,
    isChallengeAccessible
  };
};
// ===== Sprint 9.8 Requirement Gate Engine END =====